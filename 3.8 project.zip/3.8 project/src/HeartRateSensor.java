/***********************************************
 * Ralph Epperson
 * 12/06/2025
 * SDC 330 Class Project Weekend Sleep Mode
 * 
 * This Program is for doing the following. This program will Set alarm based off the moment your heart rate enters a moment of rest heart to then give you 8 hours of rest without having to worry about setting an alarm. 
 */

// ----------------- HeartRateSensor -----------------
public class HeartRateSensor {

    private int currentHeartRate;
    private boolean active;

    public HeartRateSensor() {
        this.currentHeartRate = 70;
        this.active = false;
    }

    public void start() {
        active = true;
    }

    public void stop() {
        active = false;
    }

    public int readHeartRate() {
        if (!active) return -1;

        // Simulated HR – in real use this comes from the hardware
        currentHeartRate = (int)(50 + Math.random() * 30);
        return currentHeartRate;
    }

    protected void setCurrentHeartRate(int hr) {
        this.currentHeartRate = hr;
    }
}