/***********************************************
 * Ralph Epperson
 * 12/06/2025
 * SDC 330 Class Project Weekend Sleep Mode
 * 
 * This Program is for doing the following. This program will Set alarm based off the moment your heart rate enters a moment of rest heart to then give you 8 hours of rest without having to worry about setting an alarm. 
 */
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
// ----------------- AlarmScheduler -----------------
public class AlarmScheduler {

    private LocalDateTime wakeTime;
    private boolean alarmSet;

    public AlarmScheduler() {
        alarmSet = false;
    }

    public void scheduleWakeUp(LocalDateTime sleepTime) {
        wakeTime = sleepTime.plus(8, ChronoUnit.HOURS);
        alarmSet = true;
    }

    public LocalDateTime getWakeTime() {
        return wakeTime;
    }

    public boolean isAlarmSet() {
        return alarmSet;
    }

    public void clearAlarm() {
        alarmSet = false;
    }
}