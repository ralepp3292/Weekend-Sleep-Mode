/***********************************************
 * Ralph Epperson
 * 12/06/2025
 * SDC 330 Class Project Weekend Sleep Mode
 * 
 * This Program is for doing the following. This program will Set alarm based off the moment your heart rate enters a moment of rest heart to then give you 8 hours of rest without having to worry about setting an alarm. 
 */

public class App {

    public static void main(String[] args) {

        System.out.println("=== Weekend Sleep Mode Test App ===");

        // Create the WeekendSleepMode system
        WeekendSleepMode sleepMode = new WeekendSleepMode();

        // Enable monitoring (simulated)
        System.out.println("Enabling Weekend Sleep Mode...");
        sleepMode.enable();

        // Show status after enabling
        System.out.println("Current Status:");
        System.out.println(sleepMode.toString());

        // Disable the system (cleanup)
        System.out.println("\nDisabling Weekend Sleep Mode...");
        sleepMode.disable();

        // Final status
        System.out.println("Final Status:");
        System.out.println(sleepMode.toString());

        System.out.println("=== End of Test ===");
    }
}
