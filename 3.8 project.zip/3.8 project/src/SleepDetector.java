/***********************************************
 * Ralph Epperson
 * 12/06/2025
 * SDC 330 Class Project Weekend Sleep Mode
 * 
 * This Program is for doing the following. This program will Set alarm based off the moment your heart rate enters a moment of rest heart to then give you 8 hours of rest without having to worry about setting an alarm. 
 */

// ----------------- SleepDetector -----------------
public class SleepDetector {

    private boolean asleep;
    private int thresholdHR;
    private HeartRateSensor sensor;

    public SleepDetector(HeartRateSensor sensor, int thresholdHR) {
        this.sensor = sensor;
        this.thresholdHR = thresholdHR;
        this.asleep = false;
    }

    public boolean checkIfAsleep() {
        int hr = sensor.readHeartRate();

        if (hr != -1 && hr < thresholdHR) {
            asleep = true;
        }
        return asleep;
    }

    public boolean isAsleep() {
        return asleep;
    }

    public void reset() {
        asleep = false;
    }
}