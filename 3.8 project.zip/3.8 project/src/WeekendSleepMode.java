/***********************************************
 * Ralph Epperson
 * 12/06/2025
 * SDC 330 Class Project Weekend Sleep Mode
 * 
 * This Program is for doing the following. This program will Set alarm based off the moment your heart rate enters a moment of rest heart to then give you 8 hours of rest without having to worry about setting an alarm. 
 */

import java.time.LocalDateTime;

// ----------------- WeekendSleepMode -----------------
public class WeekendSleepMode {

    private HeartRateSensor sensor;
    private SleepDetector sleepDetector;
    private AlarmScheduler alarmScheduler;
    private boolean enabled;

    public WeekendSleepMode() {
        sensor = new HeartRateSensor();
        sleepDetector = new SleepDetector(sensor, 60);
        alarmScheduler = new AlarmScheduler();
        enabled = false;
    }

    public void enable() {
        enabled = true;
        sensor.start();
        monitor();
    }

    public void disable() {
        enabled = false;
        sensor.stop();
    }

    private void monitor() {
        while (enabled && !sleepDetector.isAsleep()) {
            sleepDetector.checkIfAsleep();
            try { Thread.sleep(3000); } 
            catch (InterruptedException e) { }
        }

        if (sleepDetector.isAsleep()) {
            alarmScheduler.scheduleWakeUp(LocalDateTime.now());
        }
    }

    @Override
    public String toString() {
        return "WeekendSleepMode {" +
                "enabled=" + enabled +
                ", asleep=" + sleepDetector.isAsleep() +
                ", alarmSet=" + alarmScheduler.isAlarmSet() +
                ", wakeTime=" + alarmScheduler.getWakeTime() +
                "}";
    }
}
